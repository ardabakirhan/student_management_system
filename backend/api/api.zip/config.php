<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ── Database credentials — edit these before uploading ───────
define('DB_HOST', 'localhost');
define('DB_NAME', 'rezonans_db');
define('DB_USER', 'rezonans_admin');
define('DB_PASS', 'vEbF0)72hsPLb998');
define('DB_CHARSET', 'utf8mb4');

// Session lifetime in seconds (24 hours)
define('SESSION_TTL', 86400);

// ── CORS — allow requests from the Next.js app and Capacitor ─
$allowed_origins = [
    'http://localhost:3000',
    'http://localhost',
    'capacitor://localhost',
    'ionic://localhost',
    'https://rezonansetimesgut.com.tr',
];

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($origin, $allowed_origins, true)) {
    header('Access-Control-Allow-Origin: ' . $origin);
} else {
    header('Access-Control-Allow-Origin: *');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Max-Age: 86400');
header('Content-Type: application/json; charset=utf-8');

// Pre-flight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ── DB connection ─────────────────────────────────────────────
function db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        json_error('Veritabanı bağlantısı başarısız: ' . $e->getMessage(), 503);
    }
    return $pdo;
}

// ── JSON helpers ──────────────────────────────────────────────
function json_ok(mixed $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function json_error(string $message, int $status = 400): never {
    http_response_code($status);
    echo json_encode(['error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

function get_body(): array {
    $raw = file_get_contents('php://input');
    if (empty($raw)) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function require_method(string $method): void {
    if ($_SERVER['REQUEST_METHOD'] !== strtoupper($method)) {
        json_error('Method not allowed.', 405);
    }
}

// ── Auth helpers ──────────────────────────────────────────────

/**
 * Reads Bearer token from Authorization header or ?token= query param.
 * Returns the full session + user array on success, calls json_error on failure.
 */
function require_auth(): array {
    $token = null;

    $auth_header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (str_starts_with($auth_header, 'Bearer ')) {
        $token = substr($auth_header, 7);
    }
    if (!$token && isset($_GET['token'])) {
        $token = $_GET['token'];
    }
    if (!$token) {
        json_error('Kimlik doğrulama gerekli.', 401);
    }

    $stmt = db()->prepare(
        'SELECT s.user_id, s.expires_at, u.id, u.name, u.email, u.role, u.student_id, u.branch, u.must_change_password
         FROM sessions s
         JOIN users u ON u.id = s.user_id
         WHERE s.token = ?
           AND s.expires_at > NOW()'
    );
    $stmt->execute([$token]);
    $row = $stmt->fetch();

    if (!$row) {
        json_error('Oturum geçersiz veya süresi dolmuş.', 401);
    }

    return [
        'token' => $token,
        'id'    => (int) $row['id'],
        'name'  => $row['name'],
        'email' => $row['email'],
        'role'  => $row['role'],
        'student_id'          => $row['student_id'] ? (int) $row['student_id'] : null,
        'branch'              => $row['branch'],
        'must_change_password' => (bool) $row['must_change_password'],
    ];
}

function require_role(array $session, array $roles): void {
    if (!in_array($session['role'], $roles, true)) {
        json_error('Bu işlem için yetkiniz yok.', 403);
    }
}

// ── bcrypt helpers ────────────────────────────────────────────
function hash_password(string $plain): string {
    return password_hash($plain, PASSWORD_BCRYPT, ['cost' => 10]);
}

function verify_password(string $plain, string $hash): bool {
    // Fallback: allow plain-text comparison during dev/migration
    if ($hash === $plain) return true;
    return password_verify($plain, $hash);
}
